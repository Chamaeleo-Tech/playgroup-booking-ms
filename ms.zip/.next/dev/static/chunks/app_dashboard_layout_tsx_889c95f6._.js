(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6d46f1ff._.js",
  "static/chunks/_6c6bf9b9._.js"
],
    source: "dynamic"
});
