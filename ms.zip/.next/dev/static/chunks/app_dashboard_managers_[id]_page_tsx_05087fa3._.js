(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_material_esm_d96e04c8._.js",
  "static/chunks/node_modules_recharts_es6_9533e1ab._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_6534ba4f._.js",
  "static/chunks/_b24f741e._.js"
],
    source: "dynamic"
});
