(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_material_esm_e3e6f0de._.js",
  "static/chunks/node_modules_next_b4b7ca29._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_d7615d19._.js",
  "static/chunks/_fbab219a._.js"
],
    source: "dynamic"
});
