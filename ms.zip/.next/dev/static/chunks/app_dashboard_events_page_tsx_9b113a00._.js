(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_05cca9e2._.js",
  "static/chunks/node_modules_@mui_material_esm_67997dbf._.js",
  "static/chunks/node_modules_@popperjs_core_lib_ce7e5cb7._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_3a928686._.js"
],
    source: "dynamic"
});
