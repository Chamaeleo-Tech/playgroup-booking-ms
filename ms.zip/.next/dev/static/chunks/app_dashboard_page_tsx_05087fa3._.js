(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_material_esm_39d80ed7._.js",
  "static/chunks/node_modules_recharts_es6_util_23c4d85e._.js",
  "static/chunks/node_modules_recharts_es6_state_a7d4791f._.js",
  "static/chunks/node_modules_recharts_es6_component_37778d80._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_3f641891._.js",
  "static/chunks/node_modules_recharts_es6_a3e85291._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_6a4b9e08._.js",
  "static/chunks/_311bbb49._.js"
],
    source: "dynamic"
});
