(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d6a95a65._.js",
  "static/chunks/node_modules_a75ac2d8._.js"
],
    source: "dynamic"
});
