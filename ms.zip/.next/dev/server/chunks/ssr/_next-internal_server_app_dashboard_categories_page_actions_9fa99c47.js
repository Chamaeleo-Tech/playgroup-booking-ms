module.exports = [
"[project]/.next-internal/server/app/dashboard/categories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_categories_page_actions_9fa99c47.js.map