module.exports = [
"[project]/.next-internal/server/app/dashboard/managers/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_managers_page_actions_dfa6ad54.js.map