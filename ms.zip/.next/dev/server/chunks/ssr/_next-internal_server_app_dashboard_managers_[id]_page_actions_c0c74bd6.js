module.exports = [
"[project]/.next-internal/server/app/dashboard/managers/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_managers_%5Bid%5D_page_actions_c0c74bd6.js.map