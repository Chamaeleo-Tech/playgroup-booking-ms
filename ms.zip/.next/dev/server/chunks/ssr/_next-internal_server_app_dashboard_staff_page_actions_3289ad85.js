module.exports = [
"[project]/.next-internal/server/app/dashboard/staff/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_staff_page_actions_3289ad85.js.map